package net.xclient.util;

import net.minecraft.client.gui.DrawContext;
import net.xclient.gui.theme.XTheme;

/**
 * Shared drawing helpers for the "Feather-like" red UI: rounded cards,
 * drop shadows and a background blur pass. Built on {@link DrawContext}
 * so it works identically in ClickGUI, HUD editor and toast rendering.
 */
public final class RenderUtil {

    private RenderUtil() {}

    /** Filled rounded rectangle, approximated with layered fills (cheap, no shader dependency). */
    public static void roundedRect(DrawContext ctx, int x, int y, int width, int height, int radius, int color) {
        radius = Math.min(radius, Math.min(width, height) / 2);

        // center cross
        ctx.fill(x + radius, y, x + width - radius, y + height, color);
        ctx.fill(x, y + radius, x + radius, y + height - radius, color);
        ctx.fill(x + width - radius, y + radius, x + width, y + height - radius, color);

        // corners via shrinking fills (cheap circle approximation)
        int steps = Math.max(4, radius / 2);
        for (int i = 0; i < steps; i++) {
            double t = (i + 1) / (double) steps;
            int inset = (int) Math.round(radius - radius * Math.sin(Math.PI / 2 * t));
            int rowHeight = Math.max(1, radius / steps);
            int rowY = y + (steps - i - 1) * rowHeight / steps + radius / steps;
            ctx.fill(x + inset, y + radius - (i + 1) * radius / steps, x + width - inset, y + radius - i * radius / steps, color);
            ctx.fill(x + inset, y + height - radius + i * radius / steps, x + width - inset, y + height - radius + (i + 1) * radius / steps, color);
        }
    }

    /** Soft drop shadow behind a card - several translucent layers offset outward. */
    public static void dropShadow(DrawContext ctx, int x, int y, int width, int height, int radius) {
        int layers = 6;
        for (int i = layers; i > 0; i--) {
            int alpha = (int) (28 * (i / (float) layers));
            int spread = i * 2;
            roundedRect(ctx, x - spread, y - spread, width + spread * 2, height + spread * 2, radius + spread,
                    (alpha << 24));
        }
    }

    /**
     * Backdrop blur behind the ClickGUI. True gaussian blur needs a shader pass;
     * this uses a cheap dimmed-overlay approximation that reads well with the
     * translucent card system and costs nothing extra on low-end mobile GPUs.
     */
    public static void blurBackdrop(DrawContext ctx, int screenWidth, int screenHeight) {
        ctx.fill(0, 0, screenWidth, screenHeight, 0x90121016);
    }

    public static void card(DrawContext ctx, int x, int y, int width, int height, boolean highlighted) {
        dropShadow(ctx, x, y, width, height, 10);
        roundedRect(ctx, x, y, width, height, 10, highlighted ? XTheme.CARD_HOVER : XTheme.CARD_BG);
        if (highlighted) {
            roundedRect(ctx, x, y, width, 2, 0, XTheme.ACCENT);
        }
    }

    public static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }
}
