package net.xclient.core.keybind;

import net.xclient.core.event.SubscribeEvent;
import net.xclient.core.event.events.InputEvent;
import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleManager;

public class KeybindManager {

    private final ModuleManager moduleManager;

    public KeybindManager(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    @SubscribeEvent
    public void onInput(InputEvent event) {
        if (event.isMouse() || event.getAction() != InputEvent.Action.PRESS) return;

        for (Module module : moduleManager.getModules()) {
            Keybind bind = module.getKeybind();
            if (bind.isBound() && bind.getKey() == event.getKey()) {
                module.toggle();
            }
        }
    }
}
