package net.xclient.core.module;

import net.xclient.modules.hud.*;
import net.xclient.modules.misc.*;
import net.xclient.modules.movement.*;
import net.xclient.modules.optimization.*;
import net.xclient.modules.render.*;
import net.xclient.modules.utility.*;
import net.xclient.modules.world.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central registry for every {@link Module}. Register new modules here -
 * the ClickGUI and HUD editor both read from this list, nothing else needs
 * to be touched to add a feature to the UI.
 */
public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerAll() {
        // ---- HUD ----
        register(new ArmorHUD());
        register(new ArrayListModule());
        register(new ClockHUD());
        register(new CoordinatesModule());
        register(new CPSCounter());
        register(new FPSModule());
        register(new Keystrokes());
        register(new PingDisplay());
        register(new PotionHUD());
        register(new SpeedHUD());
        register(new WatermarkHUD());
        register(new SessionInfoHUD());
        register(new BiomeHUD());
        register(new DayCounter());
        register(new DirectionHUD());
        register(new MemoryHUD());
        register(new PackDisplay());
        register(new ServerInfoHUD());
        register(new ChatTimestamps());
        register(new SprintModule());

        // ---- Render / Visual ----
        register(new Crosshair());
        register(new FullbrightModule());
        register(new NoBossBar());
        register(new NoHurtCam());
        register(new TimeChanger());
        register(new ScoreboardMod());

        // ---- Optimization ----
        register(new EntityCulling());
        register(new ChunkCuller());
        register(new EntityLimiter());
        register(new ParticleLimiter());
        register(new DynamicFPS());
        register(new SmartAnimations());
        register(new AsyncChunkBuilder());
        register(new LazyChunkLoading());
        register(new OcclusionCulling());
        register(new ShaderToggle());

        // ---- Movement ----
        register(new ZoomModule());
        register(new AutoSprint());
        register(new InventoryMove());
        register(new Step());
        register(new SafeWalk());
        register(new ToggleSprint());
        register(new ParkourAssist());
        register(new AutoWalk());

        // ---- World ----
        register(new NoWeather());
        register(new ClearWater());
        register(new FogControl());
        register(new CustomSky());

        // ---- Utility ----
        register(new AutoGG());
        register(new ToolWarning());
        register(new AutoText());

        // ---- Misc ----
        register(new AntiAFK());
        register(new ChatFilter());
        register(new AutoRespawn());
        register(new MessageLogger());
        register(new AutoReply());
        register(new FriendSystem());
        register(new IgnoreList());

        modules.forEach(Module::init);
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getByCategory(ModuleCategory category) {
        return modules.stream().filter(m -> m.getCategory() == category).collect(Collectors.toList());
    }

    public Optional<Module> getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }
}
