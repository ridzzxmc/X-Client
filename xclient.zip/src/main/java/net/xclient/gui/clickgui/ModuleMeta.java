package net.xclient.gui.clickgui;

import net.minecraft.util.Identifier;
import net.xclient.core.module.Module;
import net.xclient.modules.hud.*;
import net.xclient.modules.misc.*;
import net.xclient.modules.movement.*;
import net.xclient.modules.optimization.*;
import net.xclient.modules.render.*;
import net.xclient.modules.utility.*;
import net.xclient.modules.world.*;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Presentation data for the ClickGUI mod-menu cards: which icon texture a
 * module gets, and which filter tabs (New / Hypixel / PvP) it shows up under.
 * <p>
 * This is intentionally kept OUTSIDE {@link Module} and keyed by class
 * (not by display name) so that:
 * - the 58 module classes never need touching just to add a picture, and
 * - a typo here can never silently point at the wrong module (a wrong
 * class reference fails to compile; a wrong string would not).
 * <p>
 * A module with no entry below simply falls back to a plain initial-letter
 * badge in the GUI - see ClickGUIScreen - so leaving one out is always safe.
 */
public final class ModuleMeta {

    public enum Tag {
        NEW,
        HYPIXEL,
        PVP
    }

    private static final String ICON_DIR = "textures/icons/";

    private static final Map<Class<? extends Module>, String> ICONS = new HashMap<>();
    private static final Map<Class<? extends Module>, Set<Tag>> TAGS = new HashMap<>();

    private ModuleMeta() {
    }

    private static void icon(Class<? extends Module> cls, String iconFile) {
        ICONS.put(cls, iconFile);
    }

    private static void tags(Class<? extends Module> cls, Tag... tagList) {
        if (tagList.length == 0) return;
        TAGS.put(cls, EnumSet.copyOf(Arrays.asList(tagList)));
    }

    static {
        // ---------------- HUD ----------------
        icon(ArmorHUD.class, "armor");                 tags(ArmorHUD.class, Tag.HYPIXEL);
        icon(ClockHUD.class, "clock");
        icon(CoordinatesModule.class, "coordinates");  tags(CoordinatesModule.class, Tag.HYPIXEL);
        icon(CPSCounter.class, "cps");                 tags(CPSCounter.class, Tag.HYPIXEL, Tag.PVP);
        icon(FPSModule.class, "fps");                  tags(FPSModule.class, Tag.HYPIXEL);
        icon(Keystrokes.class, "keystrokes");           tags(Keystrokes.class, Tag.HYPIXEL, Tag.PVP);
        icon(PingDisplay.class, "ping");                tags(PingDisplay.class, Tag.HYPIXEL);
        icon(PotionHUD.class, "potion");                tags(PotionHUD.class, Tag.HYPIXEL, Tag.PVP);
        icon(SpeedHUD.class, "motion");
        icon(WatermarkHUD.class, "logo");
        icon(SessionInfoHUD.class, "timer");
        icon(BiomeHUD.class, "biome");
        icon(DayCounter.class, "time");                 tags(DayCounter.class, Tag.NEW);
        icon(DirectionHUD.class, "compass");
        icon(PackDisplay.class, "mod");
        icon(ServerInfoHUD.class, "ip");                tags(ServerInfoHUD.class, Tag.HYPIXEL);
        icon(ChatTimestamps.class, "chat");
        icon(SprintModule.class, "sprint");             tags(SprintModule.class, Tag.HYPIXEL);
        // ArrayListModule, MemoryHUD -> no good icon match, falls back to initial badge

        // ---------------- RENDER ----------------
        icon(Crosshair.class, "crosshair");             tags(Crosshair.class, Tag.HYPIXEL, Tag.PVP);
        icon(FullbrightModule.class, "glow");           tags(FullbrightModule.class, Tag.HYPIXEL);
        icon(NoBossBar.class, "failed");
        icon(NoHurtCam.class, "heal");                  tags(NoHurtCam.class, Tag.PVP);
        icon(TimeChanger.class, "time");
        icon(ScoreboardMod.class, "scoreboard");        tags(ScoreboardMod.class, Tag.HYPIXEL, Tag.PVP);

        // ---------------- OPTIMIZATION ----------------
        icon(EntityLimiter.class, "chain");
        icon(ParticleLimiter.class, "chain");
        icon(DynamicFPS.class, "fps");
        icon(SmartAnimations.class, "motion");          tags(SmartAnimations.class, Tag.NEW);
        icon(ShaderToggle.class, "color");              tags(ShaderToggle.class, Tag.NEW);
        // EntityCulling, ChunkCuller, AsyncChunkBuilder, LazyChunkLoading, OcclusionCulling -> fallback badge

        // ---------------- MOVEMENT ----------------
        icon(ZoomModule.class, "camera");               tags(ZoomModule.class, Tag.HYPIXEL);
        icon(AutoSprint.class, "run");
        icon(ToggleSprint.class, "run");
        icon(ParkourAssist.class, "waypoint");          tags(ParkourAssist.class, Tag.NEW);
        icon(AutoWalk.class, "motion");
        // InventoryMove, Step, SafeWalk -> fallback badge

        // ---------------- WORLD ----------------
        icon(NoWeather.class, "failed");
        icon(FogControl.class, "fog");
        // ClearWater, CustomSky -> fallback badge

        // ---------------- UTILITY ----------------
        icon(AutoGG.class, "chat1");                    tags(AutoGG.class, Tag.HYPIXEL, Tag.PVP);
        icon(AutoText.class, "chat");
        // ToolWarning -> fallback badge, tagged Hypixel (durability warnings matter there)
        tags(ToolWarning.class, Tag.HYPIXEL);

        // ---------------- MISC ----------------
        icon(AntiAFK.class, "clock");
        icon(ChatFilter.class, "chat1");                tags(ChatFilter.class, Tag.NEW);
        icon(AutoRespawn.class, "heal");
        icon(MessageLogger.class, "chat1");
        icon(AutoReply.class, "chat");
        icon(IgnoreList.class, "failed");
        // FriendSystem -> fallback badge
    }

    /** Returns the icon texture identifier for this module, or null if it should use the fallback badge. */
    public static Identifier iconFor(Module module) {
        String file = ICONS.get(module.getClass());
        if (file == null) return null;
        return Identifier.of("xclient", ICON_DIR + file + ".png");
    }

    public static Set<Tag> tagsFor(Module module) {
        return TAGS.getOrDefault(module.getClass(), Set.of());
    }

    public static boolean isNew(Module module) {
        return tagsFor(module).contains(Tag.NEW);
    }

    public static boolean isHypixel(Module module) {
        return tagsFor(module).contains(Tag.HYPIXEL);
    }

    public static boolean isPvp(Module module) {
        return tagsFor(module).contains(Tag.PVP);
    }
}
