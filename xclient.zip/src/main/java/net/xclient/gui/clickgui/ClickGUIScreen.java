package net.xclient.gui.clickgui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.xclient.XClientMod;
import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.gui.theme.XTheme;
import net.xclient.util.Easing;
import net.xclient.util.RenderUtil;

import java.util.List;

/**
 * Feather-style ClickGUI: a horizontal row of category columns, each holding
 * vertically stacked module cards. Clicking a card toggles the module;
 * clicking its gear icon opens {@link ModuleSettingsPanel} beside it.
 */
public class ClickGUIScreen extends Screen {

    private static final int COLUMN_WIDTH = 160;
    private static final int COLUMN_GAP = 12;
    private static final int CARD_HEIGHT = 26;
    private static final int CARD_GAP = 6;
    private static final int TOGGLE_ANIM_MS = 180;

    private long openedAt;
    private ModuleCategory expandedSettingsCategory;
    private Module expandedSettingsModule;

    public ClickGUIScreen() {
        super(Text.literal("X Client"));
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        RenderUtil.blurBackdrop(ctx, width, height);

        float openProgress = (float) Easing.easeOutBack(Math.min(1.0, (System.currentTimeMillis() - openedAt) / 220.0));

        ModuleCategory[] categories = ModuleCategory.values();
        int totalWidth = categories.length * COLUMN_WIDTH + (categories.length - 1) * COLUMN_GAP;
        int startX = (width - totalWidth) / 2;
        int startY = 48;

        // Title
        ctx.drawText(textRenderer, Text.literal("X Client"), startX, 20, XTheme.ACCENT, true);
        ctx.drawText(textRenderer, Text.literal("Right Shift to close"), startX + textRenderer.getWidth("X Client") + 10, 24, XTheme.TEXT_SECONDARY, false);

        int columnX = startX;
        for (ModuleCategory category : categories) {
            renderColumn(ctx, category, columnX, startY, mouseX, mouseY, openProgress);
            columnX += COLUMN_WIDTH + COLUMN_GAP;
        }

        if (expandedSettingsModule != null) {
            ModuleSettingsPanel.render(ctx, expandedSettingsModule, mouseX, mouseY);
        }
    }

    private void renderColumn(DrawContext ctx, ModuleCategory category, int x, int y, int mouseX, int mouseY, float openProgress) {
        List<Module> modules = XClientMod.getModuleManager().getByCategory(category);

        // Column header
        ctx.drawText(textRenderer, Text.literal(category.getDisplayName().toUpperCase()), x + 4, y, XTheme.TEXT_SECONDARY, false);

        if (category == ModuleCategory.HUD) {
            ctx.drawText(textRenderer, Text.literal("Edit Layout"), x + COLUMN_WIDTH - textRenderer.getWidth("Edit Layout") - 4, y, XTheme.ACCENT, false);
        }

        int cardY = y + 14;

        for (Module module : modules) {
            float animT = (float) Easing.easeInOutCubic(module.getAnimationProgress(TOGGLE_ANIM_MS));
            int slideOffset = (int) (10 * (1 - openProgress));

            boolean hovered = mouseX >= x && mouseX <= x + COLUMN_WIDTH && mouseY >= cardY + slideOffset && mouseY <= cardY + CARD_HEIGHT + slideOffset;

            RenderUtil.card(ctx, x, cardY + slideOffset, COLUMN_WIDTH, CARD_HEIGHT, hovered);

            // toggle pill
            int pillW = 28, pillH = 14;
            int pillX = x + COLUMN_WIDTH - pillW - 8;
            int pillY = cardY + slideOffset + (CARD_HEIGHT - pillH) / 2;
            int pillColor = module.isEnabled()
                    ? blendColor(XTheme.TOGGLE_OFF, XTheme.TOGGLE_ON, module.isAnimating() ? animT : 1f)
                    : blendColor(XTheme.TOGGLE_ON, XTheme.TOGGLE_OFF, module.isAnimating() ? animT : 1f);
            RenderUtil.roundedRect(ctx, pillX, pillY, pillW, pillH, pillH / 2, pillColor);

            float knobT = module.isEnabled() ? (module.isAnimating() ? animT : 1f) : (module.isAnimating() ? 1f - animT : 0f);
            int knobX = pillX + 2 + Math.round((pillW - pillH) * knobT);
            RenderUtil.roundedRect(ctx, knobX, pillY + 2, pillH - 4, pillH - 4, (pillH - 4) / 2, 0xFFFFFFFF);

            int textColor = module.isEnabled() ? XTheme.TEXT_PRIMARY : XTheme.TEXT_SECONDARY;
            ctx.drawText(textRenderer, module.getName(), x + 10, cardY + slideOffset + (CARD_HEIGHT - 8) / 2, textColor, false);

            cardY += CARD_HEIGHT + CARD_GAP;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        ModuleCategory[] categories = ModuleCategory.values();
        int totalWidth = categories.length * COLUMN_WIDTH + (categories.length - 1) * COLUMN_GAP;
        int startX = (width - totalWidth) / 2;
        int startY = 48;

        int columnX = startX;
        for (ModuleCategory category : categories) {
            if (category == ModuleCategory.HUD) {
                int headerY = startY;
                String label = "Edit Layout";
                int labelX = columnX + COLUMN_WIDTH - textRenderer.getWidth(label) - 4;
                if (mouseX >= labelX && mouseX <= labelX + textRenderer.getWidth(label)
                        && mouseY >= headerY && mouseY <= headerY + 10) {
                    close();
                    net.minecraft.client.MinecraftClient.getInstance().setScreen(new net.xclient.gui.hud.HudEditorScreen());
                    return true;
                }
            }

            List<Module> modules = XClientMod.getModuleManager().getByCategory(category);
            int cardY = startY + 14;

            for (Module module : modules) {
                if (mouseX >= columnX && mouseX <= columnX + COLUMN_WIDTH && mouseY >= cardY && mouseY <= cardY + CARD_HEIGHT) {
                    int pillX = columnX + COLUMN_WIDTH - 28 - 8;
                    if (mouseX >= pillX - 4) {
                        module.toggle();
                    } else {
                        expandedSettingsModule = (expandedSettingsModule == module) ? null : module;
                    }
                    return true;
                }
                cardY += CARD_HEIGHT + CARD_GAP;
            }
            columnX += COLUMN_WIDTH + COLUMN_GAP;
        }

        expandedSettingsModule = null;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        XClientMod.getConfigManager().save(XClientMod.getModuleManager());
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static int blendColor(int from, int to, float t) {
        int a1 = (from >> 24) & 0xFF, r1 = (from >> 16) & 0xFF, g1 = (from >> 8) & 0xFF, b1 = from & 0xFF;
        int a2 = (to >> 24) & 0xFF, r2 = (to >> 16) & 0xFF, g2 = (to >> 8) & 0xFF, b2 = to & 0xFF;
        int a = Math.round(Easing.lerp(a1, a2, t));
        int r = Math.round(Easing.lerp(r1, r2, t));
        int g = Math.round(Easing.lerp(g1, g2, t));
        int b = Math.round(Easing.lerp(b1, b2, t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
