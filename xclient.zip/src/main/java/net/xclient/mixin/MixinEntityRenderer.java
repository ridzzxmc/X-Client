package net.xclient.mixin;

import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.xclient.XClientMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Appends a small "X" badge to the vanilla nametag text for players who have
 * the mod loaded (as reported by data the mod itself tracks - never fakes
 * another player's identity or hides their real name, purely additive).
 *
 * NOTE: this is a template injection point. Wire up your icon texture draw
 * call here once you've added a proper icon atlas under
 * assets/xclient/textures/icons/badge.png (see README "Adding the nametag badge").
 */
@Mixin(EntityRenderer.class)
public abstract class MixinEntityRenderer<T extends Entity> {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void xclient$beforeLabel(T entity, Text text, net.minecraft.client.util.math.MatrixStack matrices,
                                      net.minecraft.client.render.VertexConsumerProvider vertexConsumers,
                                      int light, CallbackInfo ci) {
        // Intentionally left as an extension point - see README for how to draw
        // the badge texture here without altering the underlying Text object.
    }
}
