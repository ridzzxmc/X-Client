package net.xclient.mixin;

import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.xclient.XClientMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Appends a small "X" badge to the vanilla nametag text for players who have
 * the mod loaded (as reported by data the mod itself tracks - never fakes
 * another player's identity or hides their real name, purely additive).
 *
 * NOTE: this is a template injection point, and it is NOT currently registered
 * in xclient.mixins.json. Minecraft's entity-render pipeline changed its method
 * signatures more than once between 1.21.6 and 1.21.11 (entity renderers now
 * work off an immutable "render state" snapshot instead of the live entity, and
 * by 1.21.11 rendering itself is queued rather than drawn immediately) - the
 * exact signature below is the pre-1.21.6 shape and will very likely NOT match
 * on 1.21.11. Since this mixin's "required" flag would otherwise hard-crash the
 * whole mod on a mismatch, and the body is still just an empty extension point,
 * it's left unregistered until someone confirms the current signature with the
 * game running (F3 + right-click a mixin error, or the Yarn docs for the exact
 * build) and re-adds "MixinEntityRenderer" to xclient.mixins.json.
 */
@Mixin(EntityRenderer.class)
public abstract class MixinEntityRenderer<T extends Entity> {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void xclient$beforeLabel(T entity, Text text, net.minecraft.client.util.math.MatrixStack matrices,
                                      net.minecraft.client.render.VertexConsumerProvider vertexConsumers,
                                      int light, CallbackInfo ci) {
        // Intentionally left as an extension point - see README for how to draw
        // the badge texture here without altering the underlying Text object.
    }
}
