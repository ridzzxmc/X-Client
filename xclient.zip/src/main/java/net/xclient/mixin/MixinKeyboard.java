package net.xclient.mixin;

import net.minecraft.client.Keyboard;
import net.xclient.core.event.EventBus;
import net.xclient.core.event.events.InputEvent;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

/**
 * Bridges GLFW key callbacks into {@link InputEvent}, so modules like
 * {@code KeybindManager} never touch GLFW directly. Fires alongside vanilla
 * key handling - it observes only, never cancels or rewrites input.
 */
@Mixin(Keyboard.class)
public class MixinKeyboard {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void xclient$onKey(long window, int key, int scancode, int action, int modifiers, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        InputEvent.Action mapped = switch (action) {
            case GLFW.GLFW_PRESS -> InputEvent.Action.PRESS;
            case GLFW.GLFW_RELEASE -> InputEvent.Action.RELEASE;
            default -> InputEvent.Action.REPEAT;
        };
        EventBus.INSTANCE.post(new InputEvent(key, mapped, false));
    }
}
