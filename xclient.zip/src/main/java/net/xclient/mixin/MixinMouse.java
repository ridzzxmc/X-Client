package net.xclient.mixin;

import net.minecraft.client.Mouse;
import net.xclient.core.event.EventBus;
import net.xclient.core.event.events.InputEvent;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MixinMouse {

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void xclient$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        InputEvent.Action mapped = action == GLFW.GLFW_PRESS ? InputEvent.Action.PRESS : InputEvent.Action.RELEASE;
        EventBus.INSTANCE.post(new InputEvent(button, mapped, true));
    }
}
