package net.xclient.modules.world;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Pushes the fog start/end distance out (or in, for extra fill-rate
 * headroom) - same category as vanilla's render-distance fog, just exposed
 * as its own slider instead of being tied 1:1 to render distance.
 */
public class FogControl extends Module {

    private final SliderSetting fogDistance = register(new SliderSetting("Fog Distance", 1.0, 0.2, 2.0, 0.1));

    public FogControl() {
        super("Fog Control", "Adjusts world fog start/end distance independently of render distance.",
                ModuleCategory.WORLD);
    }

    public double getFogMultiplier() {
        return fogDistance.getValue();
    }
}
