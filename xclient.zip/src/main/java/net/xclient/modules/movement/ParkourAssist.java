package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * Renders a small edge-of-block indicator so you can time jumps yourself -
 * it does NOT auto-jump or auto-move the player. Purely an informational
 * overlay, same category as a distance-to-edge HUD number.
 */
public class ParkourAssist extends Module {

    public ParkourAssist() {
        super("Parkour Assist", "Shows a visual indicator for jump timing - does not jump for you.",
                ModuleCategory.MOVEMENT);
    }
}
