package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * Applies the same "don't walk off the edge" collision behavior as holding
 * shift, without the crouched camera and slower speed - a comfort feature,
 * not a movement-speed exploit.
 */
public class SafeWalk extends Module {

    public SafeWalk() {
        super("Safe Walk", "Stops you walking off ledges without crouching.", ModuleCategory.MOVEMENT);
    }
}
