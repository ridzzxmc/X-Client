package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Classic "OptiFine-style" zoom: while the bound key is held, FOV is smoothly
 * reduced. No effect on hitboxes, reach, or aiming precision - purely a
 * camera FOV change identical to manually adjusting the FOV slider.
 */
public class ZoomModule extends Module {

    private final SliderSetting zoomFov = register(new SliderSetting("Zoom FOV", 15, 5, 50, 1, true));
    private boolean zooming;
    private double previousFov;

    public ZoomModule() {
        super("Zoom", "Hold the keybind to smoothly zoom in, like a spyglass.", ModuleCategory.MOVEMENT, true);
    }

    public void setZooming(boolean zooming) {
        if (this.zooming == zooming) return;
        this.zooming = zooming;
        if (zooming) {
            previousFov = mc.options.getFov().getValue();
        }
    }

    public boolean isZooming() {
        return zooming;
    }

    public double getZoomFov() {
        return zoomFov.getValue();
    }

    public double getPreviousFov() {
        return previousFov;
    }
}
