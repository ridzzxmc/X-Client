package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.ModeSetting;

import java.util.List;

/**
 * Sends a single configurable "away" reply the first time each player
 * whispers you while enabled - an away-message feature, not a spam bot
 * (it never repeats to the same sender until re-enabled).
 */
public class AutoReply extends Module {

    private final ModeSetting reply = register(new ModeSetting("Reply",
            List.of("I'm away right now.", "Busy, back soon!", "AFK - will reply later."),
            "I'm away right now."));

    public AutoReply() {
        super("Auto Reply", "Sends one away-message reply per whisper while enabled.", ModuleCategory.MISC);
    }

    public String getReply() {
        return reply.getValue();
    }
}
