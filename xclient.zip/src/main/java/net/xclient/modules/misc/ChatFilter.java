package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Hides incoming chat lines matching user-added regex/keyword filters
 * (e.g. spam ads, join/leave floods) on the client only - never touches
 * what's actually sent or stored server-side.
 */
public class ChatFilter extends Module {

    private final List<Pattern> filters = new ArrayList<>();

    public ChatFilter() {
        super("Chat Filter", "Hides chat messages matching your keyword/regex filters.", ModuleCategory.MISC);
    }

    public void addFilter(String regex) {
        filters.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
    }

    public boolean shouldHide(String message) {
        return filters.stream().anyMatch(p -> p.matcher(message).find());
    }
}
