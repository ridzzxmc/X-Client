package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/** Automatically respawns you on death, same as clicking the "Respawn" button yourself. */
public class AutoRespawn extends Module {

    public AutoRespawn() {
        super("Auto Respawn", "Automatically clicks Respawn when you die.", ModuleCategory.MISC, true);
    }
}
