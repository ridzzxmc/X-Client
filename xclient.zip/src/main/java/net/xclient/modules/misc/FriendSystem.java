package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * A local list of player names to visually highlight (e.g. in the
 * ArrayList/nametag color) - a client-side favorites list, not a
 * data-sharing or tracking system.
 */
public class FriendSystem extends Module {

    private final Set<String> friends = new LinkedHashSet<>();

    public FriendSystem() {
        super("Friend System", "Highlights player names you've marked as friends.", ModuleCategory.MISC, true);
    }

    public void addFriend(String name) {
        friends.add(name.toLowerCase());
    }

    public void removeFriend(String name) {
        friends.remove(name.toLowerCase());
    }

    public boolean isFriend(String name) {
        return friends.contains(name.toLowerCase());
    }

    public Set<String> getFriends() {
        return friends;
    }
}
