package net.xclient.modules.hud;

import net.minecraft.client.gui.DrawContext;
import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Base for every HUD widget. Handles the shared drag/resize/scale state that
 * the HUD editor screen manipulates - concrete HUD modules only implement
 * {@link #renderContent(DrawContext, int, int)} and report their own size.
 */
public abstract class HudModule extends Module {

    protected float x;
    protected float y;
    protected final SliderSetting scale = register(new SliderSetting("Scale", 1.0, 0.5, 2.0, 0.05));

    private boolean dragging = false;

    protected HudModule(String name, String description, float defaultX, float defaultY) {
        super(name, description, ModuleCategory.HUD);
        this.x = defaultX;
        this.y = defaultY;
    }

    protected HudModule(String name, String description, float defaultX, float defaultY, boolean enabledByDefault) {
        super(name, description, ModuleCategory.HUD, enabledByDefault);
        this.x = defaultX;
        this.y = defaultY;
    }

    /** Draws only this widget's content at (0,0); the caller translates to {@link #x}, {@link #y}. */
    protected abstract void renderContent(DrawContext ctx, int screenWidth, int screenHeight);

    /** Reported footprint in unscaled pixels, used by the HUD editor for the drag outline and overlap avoidance. */
    public abstract int getWidth();

    public abstract int getHeight();

    @net.xclient.core.event.SubscribeEvent
    private void xclient$onRenderEvent(net.xclient.core.event.events.RenderEvent event) {
        if (event.getType() != net.xclient.core.event.events.RenderEvent.Type.HUD_2D) return;
        render(event.getDrawContext(), mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    }

    public final void render(DrawContext ctx, int screenWidth, int screenHeight) {
        if (!isEnabled()) return;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale((float) scale.getValue(), (float) scale.getValue());
        renderContent(ctx, screenWidth, screenHeight);
        ctx.getMatrices().popMatrix();
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getScale() {
        return scale.getValue().floatValue();
    }

    public boolean isDragging() {
        return dragging;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }
}
