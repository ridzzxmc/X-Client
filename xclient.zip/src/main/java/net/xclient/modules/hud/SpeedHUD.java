package net.xclient.modules.hud;

import net.minecraft.client.gui.DrawContext;
import net.xclient.gui.theme.XTheme;

public class SpeedHUD extends HudModule {

    private double lastX, lastZ;
    private double bps;

    public SpeedHUD() {
        super("Speed", "Shows your horizontal movement speed in blocks/second.", 6, 208);
    }

    @Override
    protected void renderContent(DrawContext ctx, int screenWidth, int screenHeight) {
        if (mc.player == null) return;

        double dx = mc.player.getX() - lastX;
        double dz = mc.player.getZ() - lastZ;
        bps = Math.sqrt(dx * dx + dz * dz) * 20; // per-frame delta * ticks/sec approximation
        lastX = mc.player.getX();
        lastZ = mc.player.getZ();

        String text = String.format("%.2f b/s", Math.min(bps, 43.0));
        int width = mc.textRenderer.getWidth(text) + 12;
        ctx.fill(0, 0, width, 14, XTheme.PANEL_BG);
        ctx.fill(0, 0, 3, 14, XTheme.ACCENT);
        ctx.drawText(mc.textRenderer, text, 6, 3, XTheme.TEXT_PRIMARY, true);
    }

    @Override
    public int getWidth() {
        return 90;
    }

    @Override
    public int getHeight() {
        return 14;
    }
}
