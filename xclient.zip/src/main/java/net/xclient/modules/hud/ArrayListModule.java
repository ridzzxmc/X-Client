package net.xclient.modules.hud;

import net.minecraft.client.gui.DrawContext;
import net.xclient.XClientMod;
import net.xclient.core.module.Module;
import net.xclient.gui.theme.XTheme;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayListModule extends HudModule {

    public ArrayListModule() {
        // Default position sits near the top-right for a standard 1920-wide display;
        // drag it in the HUD editor to fit your resolution, position is saved after.
        super("ArrayList", "Lists currently active modules.", 1770, 6, true);
    }

    @Override
    protected void renderContent(DrawContext ctx, int screenWidth, int screenHeight) {
        List<Module> active = XClientMod.getModuleManager().getModules().stream()
                .filter(Module::isEnabled)
                .filter(m -> m != this)
                .sorted(Comparator.comparingInt((Module m) -> -mc.textRenderer.getWidth(m.getName())))
                .collect(Collectors.toList());

        int rowY = 0;
        for (Module module : active) {
            int textWidth = mc.textRenderer.getWidth(module.getName());
            int rowX = getWidth() - textWidth - 8;

            ctx.fill(rowX - 4, rowY, rowX + textWidth + 4, rowY + 12, XTheme.PANEL_BG);
            ctx.fill(rowX + textWidth + 4 - 2, rowY, rowX + textWidth + 4, rowY + 12, XTheme.ACCENT);
            ctx.drawText(mc.textRenderer, module.getName(), rowX, rowY + 2, XTheme.TEXT_PRIMARY, false);

            rowY += 13;
        }
    }

    /** x is anchored so content renders flush against right edge - editor drags update this normally. */
    @Override
    public int getWidth() {
        return 140;
    }

    @Override
    public int getHeight() {
        return 13 * Math.max(1, (int) XClientMod.getModuleManager().getModules().stream().filter(Module::isEnabled).count());
    }
}
