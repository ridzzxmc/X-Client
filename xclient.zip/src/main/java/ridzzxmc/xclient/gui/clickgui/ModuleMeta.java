package ridzzxmc.xclient.gui.clickgui;

import net.minecraft.util.Identifier;
import ridzzxmc.xclient.XClientMod;
import ridzzxmc.xclient.core.module.Module;
import ridzzxmc.xclient.modules.cosmetic.XClientCape;
import ridzzxmc.xclient.modules.hud.*;
import ridzzxmc.xclient.modules.misc.*;
import ridzzxmc.xclient.modules.movement.AutoSprint;
import ridzzxmc.xclient.modules.movement.ZoomModule;
import ridzzxmc.xclient.modules.optimization.SmartAnimations;
import ridzzxmc.xclient.modules.render.*;
import ridzzxmc.xclient.modules.utility.AutoGG;
import ridzzxmc.xclient.modules.utility.AutoText;
import ridzzxmc.xclient.modules.utility.ToolWarning;
import ridzzxmc.xclient.modules.world.ClearWater;
import ridzzxmc.xclient.modules.world.NoWeather;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Presentation data for the ClickGUI mod-menu cards: which filter tabs
 * (currently just New) a module shows up under, and - now that cards are
 * icon-centered again to match the reference card style - which icon under
 * {@code assets/xclient/textures/icons/} each module shows.
 * <p>
 * Not every module has a bespoke icon asset; ones with no entry in
 * {@link #ICONS} fall back to {@link ridzzxmc.xclient.util.RenderUtil#initialBadge}
 * (a colored square with the module's first letter) in {@code renderCard()}
 * rather than being force-mapped to a mismatched icon.
 * <p>
 * This is intentionally kept OUTSIDE {@link Module} and keyed by class
 * (not by display name) so that a typo here can never silently point at the
 * wrong module (a wrong class reference fails to compile; a wrong string
 * would not).
 */
public final class ModuleMeta {

    public enum Tag {
        NEW
    }

    private static final Map<Class<? extends Module>, Set<Tag>> TAGS = new HashMap<>();
    private static final Map<Class<? extends Module>, Identifier> ICONS = new HashMap<>();

    private ModuleMeta() {
    }

    private static void tags(Class<? extends Module> cls, Tag... tagList) {
        if (tagList.length == 0) return;
        TAGS.put(cls, EnumSet.copyOf(Arrays.asList(tagList)));
    }

    private static void icon(Class<? extends Module> cls, String iconName) {
        ICONS.put(cls, Identifier.of(XClientMod.RESOURCE_NAMESPACE, "textures/icons/" + iconName + ".png"));
    }

    static {
        // ---------------- HUD ----------------
        tags(DayCounter.class, Tag.NEW);
        icon(ArmorHUD.class, "armor");
        icon(ClockHUD.class, "clock");
        icon(CoordinatesModule.class, "coordinates");
        icon(CPSCounter.class, "cps");
        icon(FPSModule.class, "fps");
        icon(Keystrokes.class, "keystrokes");
        icon(PingDisplay.class, "ping");
        icon(PotionHUD.class, "potion");
        icon(SpeedHUD.class, "motion");
        icon(WatermarkHUD.class, "logo");
        icon(SessionInfoHUD.class, "timer");
        icon(BiomeHUD.class, "biome");
        icon(DayCounter.class, "time");
        icon(DirectionHUD.class, "compass");
        icon(MemoryHUD.class, "display");
        icon(PackDisplay.class, "mod");
        icon(ServerInfoHUD.class, "ip");
        icon(ChatTimestamps.class, "chat");
        icon(SprintModule.class, "sprint");

        // ---------------- RENDER ----------------
        tags(XClientIcon.class, Tag.NEW);
        icon(HitboxModule.class, "chain");
        icon(Crosshair.class, "crosshair");
        icon(DamageIndicator.class, "heal");
        icon(FullbrightModule.class, "glow");
        icon(NoBossBar.class, "failed");
        icon(NoHurtCam.class, "failed");
        icon(PingOverlay.class, "ping");
        icon(ScoreboardMod.class, "scoreboard");
        icon(TimeChanger.class, "time");
        icon(XClientIcon.class, "logo");

        // ---------------- OPTIMIZATION ----------------
        tags(SmartAnimations.class, Tag.NEW);
        icon(SmartAnimations.class, "run");

        // ---------------- MOVEMENT ----------------
        icon(ZoomModule.class, "camera");
        icon(AutoSprint.class, "run");

        // ---------------- WORLD ----------------
        icon(NoWeather.class, "failed");
        icon(ClearWater.class, "color");

        // ---------------- UTILITY ----------------
        tags(ToolWarning.class, Tag.NEW);
        icon(AutoGG.class, "chat");
        icon(ToolWarning.class, "failed");
        icon(AutoText.class, "chat");

        // ---------------- MISC ----------------
        icon(AntiAFK.class, "run");
        icon(AutoRespawn.class, "heal");
        icon(MessageLogger.class, "link");

        // ---------------- COSMETIC ----------------
        icon(XClientCape.class, "cosmetics");
    }

    public static Set<Tag> tagsFor(Module module) {
        return TAGS.getOrDefault(module.getClass(), Set.of());
    }

    public static boolean isNew(Module module) {
        return tagsFor(module).contains(Tag.NEW);
    }

    /** The card icon for this module, or null if none is mapped (caller should fall back to an initials badge). */
    public static Identifier iconFor(Module module) {
        return ICONS.get(module.getClass());
    }
}
