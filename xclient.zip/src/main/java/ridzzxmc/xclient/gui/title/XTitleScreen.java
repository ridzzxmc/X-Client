package ridzzxmc.xclient.gui.title;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import ridzzxmc.xclient.XClientMod;
import ridzzxmc.xclient.gui.clickgui.ClickGUIScreen;
import ridzzxmc.xclient.gui.theme.XAssets;
import ridzzxmc.xclient.gui.theme.XTheme;
import ridzzxmc.xclient.util.RenderUtil;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Replacement for vanilla's {@code TitleScreen}, styled after the Feather
 * Client reference the project was given: animated panorama background,
 * brand lockup, a vertical stack of baked pill buttons (Singleplayer /
 * Multiplayer / Mod Menu), a hero Store button, and small Options/Quit
 * buttons + a version string tucked into the corners.
 * <p>
 * Swapped in for the vanilla screen by {@link XClientMod}'s
 * {@code ScreenEvents.BEFORE_INIT} hook - see that class for why a Fabric
 * API event is used here instead of a mixin. Deliberately extends
 * {@link Screen} directly (not vanilla {@code TitleScreen}) so that hook's
 * {@code instanceof TitleScreen} check can never match this class and
 * re-trigger itself.
 * <p>
 * Not attempting the realmsNotification/telemetry/multiplayer-disabled
 * banners vanilla's title screen has - this is a cosmetic reskin, not a
 * feature-complete reimplementation, and none of those are things a mod
 * should be silently suppressing anyway.
 */
public class XTitleScreen extends Screen {

    private static final Identifier LOGO_ICON = Identifier.of(XClientMod.RESOURCE_NAMESPACE, "textures/icons/logo.png");

    private static final int LOGO_SIZE = 32;
    private static final int STACK_W = 280;
    private static final int STACK_GAP = 10;
    private static final int PILL_ASPECT_H = 87; // native px height of a 480-wide baked pill button
    private static final int STORE_ASPECT_H = 121; // native px height of the 640-wide store button
    private static final int SMALL_W = 150;

    private final PanoramaBackground panorama = new PanoramaBackground();

    public XTitleScreen() {
        super(Text.literal("X Client"));
    }

    private int pillH(int w) {
        return Math.round(w * (PILL_ASPECT_H / 480f));
    }

    private int storeH(int w) {
        return Math.round(w * (STORE_ASPECT_H / 640f));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        panorama.render(ctx, width, height);

        int centerX = width / 2;
        int blockTop = stackStartY();

        // brand lockup
        RenderUtil.drawIcon(ctx, LOGO_ICON, centerX - LOGO_SIZE / 2, blockTop, LOGO_SIZE);
        String title = "X CLIENT";
        ctx.drawText(textRenderer, title, centerX - textRenderer.getWidth(title) / 2,
                blockTop + LOGO_SIZE + 8, 0xFFFFFFFF, true);

        for (MenuButton b : buildButtons(buttonStackY(blockTop))) {
            b.render(ctx, mouseX, mouseY);
        }

        ctx.drawText(textRenderer, versionString(), 6, height - 12, XTheme.TEXT_SECONDARY, false);
    }

    /** Top Y of the brand lockup (logo + "X CLIENT" text), vertically centering the whole logo+stack+store block with a slight upward bias so the corner buttons/version text below always have room. */
    private int stackStartY() {
        int stackH = pillH(STACK_W) * 3 + STACK_GAP * 2 + 16 + storeH(STACK_W);
        return Math.max(70, (height - stackH) / 2 - 40);
    }

    /** Y of the first button in the stack, i.e. just below the brand lockup started at blockTop. */
    private int buttonStackY(int blockTop) {
        return blockTop + LOGO_SIZE + 8 + 16 + 14;
    }

    /**
     * Rebuilt every call (render + mouseClicked) from a single top-Y so the
     * two can never drift apart - same reasoning as ClickGUIScreen's layout
     * math.
     * <p>
     * NOTE: {@code SelectWorldScreen(Screen)}, {@code MultiplayerScreen(Screen)}
     * and {@code OptionsScreen(Screen, GameOptions)} single/parent-arg
     * constructors are what's used here - these have been stable across
     * many Minecraft versions, but if a future Yarn mappings bump changes
     * one of their signatures, this is the one method to check.
     */
    private List<MenuButton> buildButtons(int startY) {
        List<MenuButton> buttons = new ArrayList<>();
        int centerX = width / 2;
        int x = centerX - STACK_W / 2;
        int y = startY;
        int h = pillH(STACK_W);
        MinecraftClient client = MinecraftClient.getInstance();

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_SINGLEPLAYER, XAssets.BTN_SINGLEPLAYER_HOVER,
                () -> client.setScreen(new SelectWorldScreen(this))));
        y += h + STACK_GAP;

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_MULTIPLAYER, XAssets.BTN_MULTIPLAYER_HOVER,
                () -> client.setScreen(new MultiplayerScreen(this))));
        y += h + STACK_GAP;

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_MODMENU, XAssets.BTN_MODMENU_HOVER,
                // Pass `this` through as ClickGUIScreen's parent (see that class's
                // own parent field) - with no world loaded here, closing Mod Menu
                // (or drilling further into the HUD editor and closing that) needs
                // somewhere other than null to return to, or the client is left with
                // no screen and no world.
                () -> client.setScreen(new ClickGUIScreen(this))));
        y += h + 16;

        int storeH = storeH(STACK_W);
        buttons.add(new MenuButton(x, y, STACK_W, storeH, XAssets.BTN_STORE, XAssets.BTN_STORE_HOVER,
                () -> Util.getOperatingSystem().open(URI.create("https://sociabuzz.com/ridzzxmc"))));

        // corner utility buttons, independent of the main stack's vertical flow
        int smallH = pillH(SMALL_W);
        buttons.add(new MenuButton(width - SMALL_W - 10, height - smallH - 10, SMALL_W, smallH,
                XAssets.BTN_OPTION, XAssets.BTN_OPTION_HOVER,
                () -> client.setScreen(new OptionsScreen(this, client.options))));

        int quitH = Math.round(SMALL_W * (122f / 480f));
        buttons.add(new MenuButton(10, height - quitH - 10, SMALL_W, quitH,
                XAssets.BTN_QUIT, XAssets.BTN_QUIT_HOVER,
                client::scheduleStop));

        return buttons;
    }

    private String versionString() {
        try {
            return FabricLoader.getInstance().getModContainer(XClientMod.MOD_ID)
                    .map(c -> "X Client " + c.getMetadata().getVersion().getFriendlyString())
                    .orElse("X Client");
        } catch (Exception e) {
            return "X Client";
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (MenuButton b : buildButtons(buttonStackY(stackStartY()))) {
                if (b.click((int) mouseX, (int) mouseY)) {
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void tick() {
        // Panorama is time-driven (System.currentTimeMillis()), not tick-driven - nothing needed here.
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** No world is loaded here, so unlike every other screen in this project there is nothing to close back to - default {@code Screen} behavior would let Escape call {@code close()} and leave the client with no screen and no world. */
    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
