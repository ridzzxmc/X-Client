package ridzzxmc.xclient.gui.title;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;
import ridzzxmc.xclient.XClientMod;
import ridzzxmc.xclient.gui.clickgui.ClickGUIScreen;
import ridzzxmc.xclient.gui.theme.XAssets;
import ridzzxmc.xclient.gui.theme.XTheme;
import ridzzxmc.xclient.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Replacement for vanilla's {@code GameMenuScreen} (the in-game Escape
 * menu), styled to match {@link XTitleScreen}: a centered vertical stack of
 * baked pill buttons over the dimmed/blurred game world.
 * <p>
 * Deliberately drops vanilla's Achievements / Statistics / Give Feedback /
 * Open to LAN buttons - the reference art the project was given only covers
 * Back to Game, Mod Menu, Options and the context Save-and-Quit/Disconnect
 * button, and Feather's own pause menu is similarly stripped down. Open to
 * LAN in particular is a real feature loss for singleplayer LAN hosting -
 * worth flagging if that's still wanted, since it can be added back as a
 * fifth button.
 * <p>
 * Swapped in for the vanilla screen by {@link XClientMod}'s
 * {@code ScreenEvents.BEFORE_INIT} hook, same mechanism as
 * {@link XTitleScreen} - see that class for why. Extends {@link Screen}
 * directly rather than vanilla {@code GameMenuScreen} for the same
 * no-self-recursion reason.
 */
public class XPauseScreen extends Screen {

    private static final int STACK_W = 260;
    private static final int STACK_GAP = 10;
    private static final int PILL_ASPECT_H = 87; // native px height of a 480-wide baked pill button

    public XPauseScreen() {
        super(Text.literal("X Client"));
    }

    private int pillH(int w) {
        return Math.round(w * (PILL_ASPECT_H / 480f));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dim/blur the live game world behind this screen - RenderUtil's cheap
        // dimmed-overlay approximation, same one ClickGUIScreen already uses,
        // rather than vanilla GameMenuScreen's own (now bypassed) blur pass.
        RenderUtil.blurBackdrop(ctx, width, height);

        int centerX = width / 2;
        int h = pillH(STACK_W);
        int stackH = h * 4 + STACK_GAP * 3;
        int startY = stackStartY(stackH);

        String title = "X CLIENT";
        ctx.drawText(textRenderer, title, centerX - textRenderer.getWidth(title) / 2,
                startY - 20, XTheme.TEXT_SECONDARY, true);

        for (MenuButton b : buildButtons(startY)) {
            b.render(ctx, mouseX, mouseY);
        }
    }

    private int stackStartY(int stackH) {
        return Math.max(30, (height - stackH) / 2);
    }

    /** Same "recompute from one Y every call" reasoning as XTitleScreen/ClickGUIScreen. */
    private List<MenuButton> buildButtons(int startY) {
        List<MenuButton> buttons = new ArrayList<>();
        int x = width / 2 - STACK_W / 2;
        int y = startY;
        int h = pillH(STACK_W);
        MinecraftClient client = MinecraftClient.getInstance();

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_BACKTOGAME, XAssets.BTN_BACKTOGAME_HOVER,
                () -> client.setScreen(null)));
        y += h + STACK_GAP;

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_MODMENU, XAssets.BTN_MODMENU_HOVER,
                () -> client.setScreen(new ClickGUIScreen())));
        y += h + STACK_GAP;

        buttons.add(new MenuButton(x, y, STACK_W, h, XAssets.BTN_OPTION, XAssets.BTN_OPTION_HOVER,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        y += h + STACK_GAP;

        // Vanilla shows exactly one of these two depending on context (singleplayer
        // "Save and Quit to Title" vs multiplayer "Disconnect") - both are the same
        // underlying action, MinecraftClient#disconnect(), just a different baked
        // button graphic. NOTE: `disconnect()` (no-arg) is the long-stable Yarn name
        // for this - the one call in this file worth checking first if it doesn't
        // compile against a future mappings bump.
        boolean singleplayer = client.isInSingleplayer();
        buttons.add(new MenuButton(x, y, STACK_W, h,
                singleplayer ? XAssets.BTN_SAVE : XAssets.BTN_DISCONNECT,
                singleplayer ? XAssets.BTN_SAVE_HOVER : XAssets.BTN_DISCONNECT_HOVER,
                client::disconnect));

        return buttons;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int h = pillH(STACK_W);
            int stackH = h * 4 + STACK_GAP * 3;
            for (MenuButton b : buildButtons(stackStartY(stackH))) {
                if (b.click((int) mouseX, (int) mouseY)) {
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return true;
    }
}
