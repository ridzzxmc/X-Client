package ridzzxmc.xclient.gui.title;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import ridzzxmc.xclient.gui.theme.XAssets;
import ridzzxmc.xclient.util.RenderUtil;

/**
 * A single baked-texture menu button: a normal/hover PNG pair (already
 * containing their own icon + label art, see {@link XAssets}) stretched
 * into a fixed screen rect, with a click callback.
 * <p>
 * {@link XTitleScreen} and {@link XPauseScreen} both rebuild their button
 * list from scratch on every render/click call (same "recompute layout live,
 * never cache" approach {@code ClickGUIScreen} already uses) rather than
 * keeping this as mutable state, so a window resize can never leave
 * rendering and hit-testing looking at different rectangles.
 */
public final class MenuButton {

    public final int x, y, w, h;
    private final Identifier normal;
    private final Identifier hover;
    private final Runnable onClick;

    public MenuButton(int x, int y, int w, int h, Identifier normal, Identifier hover, Runnable onClick) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.normal = normal;
        this.hover = hover;
        this.onClick = onClick;
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY) {
        RenderUtil.drawIconRect(ctx, XAssets.button(normal, hover, isHovered(mouseX, mouseY)), x, y, w, h);
    }

    /** If this button contains (mouseX, mouseY), fires its click callback and returns true. */
    public boolean click(int mouseX, int mouseY) {
        if (!isHovered(mouseX, mouseY)) return false;
        onClick.run();
        return true;
    }
}
