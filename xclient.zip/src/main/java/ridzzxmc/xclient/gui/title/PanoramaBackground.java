package ridzzxmc.xclient.gui.title;

import net.minecraft.client.gui.DrawContext;
import ridzzxmc.xclient.gui.theme.XAssets;
import ridzzxmc.xclient.util.RenderUtil;

/**
 * Slow-drifting, cross-fading background for {@link XTitleScreen}, built
 * from the 6 static panorama face images the project was given.
 * <p>
 * Deliberately NOT a true rotating 3D cubemap (that needs a dedicated
 * camera/projection pass - see vanilla's own panorama renderer). Instead
 * each face is drawn as a single oversized 2D image that slowly pans
 * within its own margin (a "Ken Burns" drift) via {@link RenderUtil#drawIconRect},
 * the exact same stretch-to-box texture trick used everywhere else in this
 * project's GUI code, and every {@code CYCLE_MS} the next face cross-fades
 * in on top using that same helper's tint/alpha overload. Cheap, has no
 * matrix/shader dependency, and can't drift out of sync with hit-testing
 * the way a true 3D pass could.
 */
public final class PanoramaBackground {

    private static final long CYCLE_MS = 9000;
    private static final long FADE_MS = 2000;
    /** How much of the oversized image's extra margin the drift is allowed to use, 0..1 - kept under 1 so the image can never pan far enough to expose an edge. */
    private static final double DRIFT_FRACTION = 0.85;
    /** Oversize factor versus the larger screen dimension, so the square source always fully covers a wide/ultrawide window with room to drift. */
    private static final double COVER_SCALE = 1.35;

    private final long startedAt = System.currentTimeMillis();

    public void render(DrawContext ctx, int screenWidth, int screenHeight) {
        long elapsed = System.currentTimeMillis() - startedAt;
        int faceCount = XAssets.PANORAMA.length;
        int index = (int) ((elapsed / CYCLE_MS) % faceCount);
        int nextIndex = (index + 1) % faceCount;
        long intoCycle = elapsed % CYCLE_MS;
        float fadeT = intoCycle > (CYCLE_MS - FADE_MS) ? (intoCycle - (CYCLE_MS - FADE_MS)) / (float) FADE_MS : 0f;

        int size = (int) Math.round(Math.max(screenWidth, screenHeight) * COVER_SCALE);
        int x = (screenWidth - size) / 2 + drift(elapsed, 0.00006, size - screenWidth);
        int y = (screenHeight - size) / 2 + drift(elapsed, 0.00004, size - screenHeight);

        ctx.enableScissor(0, 0, screenWidth, screenHeight);
        RenderUtil.drawIconRect(ctx, XAssets.PANORAMA[index], x, y, size, size);
        if (fadeT > 0f) {
            int alpha = Math.round(fadeT * 255);
            RenderUtil.drawIconRect(ctx, XAssets.PANORAMA[nextIndex], x, y, size, size, RenderUtil.withAlpha(0xFFFFFF, alpha));
        }
        ctx.disableScissor();

        // Dim the panorama so white button/title text stays legible over bright sky - same
        // near-black overlay technique as RenderUtil.blurBackdrop, just lighter.
        ctx.fill(0, 0, screenWidth, screenHeight, 0x80100C0D);
    }

    /** Sine-based drift within +-(margin/2 * DRIFT_FRACTION) so the oversized image can never expose an edge, however long the screen stays open. */
    private static int drift(long elapsedMs, double speed, int margin) {
        double amplitude = (margin / 2.0) * DRIFT_FRACTION;
        return (int) Math.round(Math.sin(elapsedMs * speed * Math.PI * 2) * amplitude);
    }
}
