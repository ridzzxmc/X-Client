package ridzzxmc.xclient.gui.theme;

import net.minecraft.util.Identifier;
import ridzzxmc.xclient.XClientMod;

/**
 * Texture {@link Identifier} constants for the "Feather-style" title/pause
 * screens (see {@link ridzzxmc.xclient.gui.title.XTitleScreen} /
 * {@link ridzzxmc.xclient.gui.title.XPauseScreen}) and the panorama
 * background they share.
 * <p>
 * Every baked button here is a single pre-rendered image (icon + label
 * already composited) with a matching "{@code *1}" hover variant, sourced
 * from the reference art the project was given and cropped/downscaled to
 * {@code assets/xclient/textures/menu/...} at build time - there is no
 * runtime compositing of icon+text, {@link #button} just picks between the
 * two whole-button textures based on hover state.
 */
public final class XAssets {

    private XAssets() {}

    private static Identifier menu(String path) {
        return Identifier.of(XClientMod.RESOURCE_NAMESPACE, "textures/menu/" + path);
    }

    // ---- baked buttons: base/hover pair, id() picks the right one ----
    public static final Identifier BTN_SINGLEPLAYER      = menu("buttons/singleplayer.png");
    public static final Identifier BTN_SINGLEPLAYER_HOVER = menu("buttons/singleplayer1.png");
    public static final Identifier BTN_MULTIPLAYER       = menu("buttons/multiplayer.png");
    public static final Identifier BTN_MULTIPLAYER_HOVER = menu("buttons/multiplayer1.png");
    public static final Identifier BTN_MODMENU           = menu("buttons/modmenu.png");
    public static final Identifier BTN_MODMENU_HOVER     = menu("buttons/modmenu1.png");
    public static final Identifier BTN_STORE             = menu("buttons/store.png");
    public static final Identifier BTN_STORE_HOVER       = menu("buttons/store2.png");
    public static final Identifier BTN_OPTION            = menu("buttons/option.png");
    public static final Identifier BTN_OPTION_HOVER      = menu("buttons/option1.png");
    public static final Identifier BTN_QUIT              = menu("buttons/q.png");
    public static final Identifier BTN_QUIT_HOVER        = menu("buttons/q1.png");
    public static final Identifier BTN_SAVE              = menu("buttons/save.png");
    public static final Identifier BTN_SAVE_HOVER        = menu("buttons/save1.png");
    public static final Identifier BTN_DISCONNECT        = menu("buttons/disconnect.png");
    public static final Identifier BTN_DISCONNECT_HOVER  = menu("buttons/disconnect1.png");
    public static final Identifier BTN_BACKTOGAME        = menu("buttons/backtogame.png");
    public static final Identifier BTN_BACKTOGAME_HOVER  = menu("buttons/backtogame1.png");

    /** Picks the normal or hover texture for a baked button pair. */
    public static Identifier button(Identifier normal, Identifier hover, boolean hovered) {
        return hovered ? hover : normal;
    }

    // ---- panorama background: 6 faces, cross-faded/panned by PanoramaBackground ----
    public static final Identifier[] PANORAMA = new Identifier[]{
            menu("panorama/panorama_0.png"),
            menu("panorama/panorama_1.png"),
            menu("panorama/panorama_2.png"),
            menu("panorama/panorama_3.png"),
            menu("panorama/panorama_4.png"),
            menu("panorama/panorama_5.png"),
    };
}
