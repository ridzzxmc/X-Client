package ridzzxmc.xclient.gui.theme;

/**
 * Single source of truth for the "X Client" red aesthetic.
 * Change values here to re-theme the whole client.
 */
public final class XTheme {

    private XTheme() {}

    public static final int ACCENT          = 0xFFE53935; // primary red
    public static final int ACCENT_DIM      = 0xFF8F2422;
    public static final int ACCENT_GLOW     = 0x55E53935;

    public static final int BACKGROUND      = 0xE6141014; // near-black w/ red tint, translucent

    /**
     * Solid black, matching the reference panel-background image the
     * project was given (a flat black rounded rectangle - sampled pixel
     * color, no gradient/texture in it) rather than the previous
     * translucent dark-red-tinted fill. Opaque on purpose: the old
     * translucency let the blurred game world show faintly through the
     * panel, which the reference does not have.
     */
    public static final int PANEL_BG        = 0xFF000000;
    public static final int CARD_BG         = 0xEE1F181B;
    public static final int CARD_HOVER      = 0xEE2A1D20;

    /**
     * Corner radius for the ClickGUI's outer sidebar/panel/header, matched
     * to the reference panel image's proportions (a noticeably rounder
     * corner than the old radius-10 panel). Cards use {@link #CARD_RADIUS}
     * instead - slightly smaller so a 3-column grid of them doesn't look
     * over-rounded at typical card sizes.
     */
    public static final int PANEL_RADIUS    = 20;
    public static final int CARD_RADIUS     = 12;

    public static final int TEXT_PRIMARY    = 0xFFF5F0F0;
    public static final int TEXT_SECONDARY  = 0xFFAFA0A2;
    public static final int TEXT_DISABLED   = 0xFF6E6265;

    public static final int TOGGLE_ON       = ACCENT;
    public static final int TOGGLE_OFF      = 0xFF3A2E31;

    public static final int SUCCESS         = 0xFF43C463;
    public static final int WARNING         = 0xFFFFB020;
    public static final int ERROR           = 0xFFE53935;

    public static final String FONT_REGULAR = "xclient:inter_regular";
    public static final String FONT_MEDIUM  = "xclient:inter_medium";
    public static final String FONT_BOLD    = "xclient:inter_bold";
}
