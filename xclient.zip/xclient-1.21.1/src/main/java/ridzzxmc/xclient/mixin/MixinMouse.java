package ridzzxmc.xclient.mixin;

import net.minecraft.client.Mouse;
import ridzzxmc.xclient.core.event.EventBus;
import ridzzxmc.xclient.core.event.events.InputEvent;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MixinMouse {

    // Pre-1.21.9 signature: Mouse#onMouseButton(long window, int button,
    // int action, int mods). The button+modifiers-as-a-single MouseInput
    // record shape only exists from 1.21.9 onward, so this version keeps
    // the classic raw GLFW-style parameters.
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void xclient$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        InputEvent.Action mapped = action == GLFW.GLFW_PRESS ? InputEvent.Action.PRESS : InputEvent.Action.RELEASE;
        EventBus.INSTANCE.post(new InputEvent(button, mapped, true));
    }
}
